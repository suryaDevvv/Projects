package com.example.Amazon.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import java.util.Objects;

@Entity
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int cartid;
    private int userid;
    private int productid;
    private String name;
    private double price;
    private int quantity;

    public Cart(int cartid, int quantity, double price, String name, int productid, int userid) {
        this.cartid = cartid;
        this.quantity = quantity;
        this.price = price;
        this.name = name;
        this.productid = productid;
        this.userid = userid;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public Cart() {
    }

    public int getCartid() {
        return cartid;
    }

    public void setCartid(int cartid) {
        this.cartid = cartid;
    }

    public int getProductid() {
        return productid;
    }

    public void setProductid(int productid) {
        this.productid = productid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Cart cart = (Cart) o;
        return cartid == cart.cartid && productid == cart.productid && Double.compare(price, cart.price) == 0 && quantity == cart.quantity && Objects.equals(name, cart.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cartid, productid, name, price, quantity);
    }

    @Override
    public String toString() {
        return "Cart{" +
                "cartid=" + cartid +
                ", productid=" + productid +
                ", name='" + name + '\'' +
                ", price=" + price +
                ", quantity=" + quantity +
                '}';
    }
}
