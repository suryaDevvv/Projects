package com.example.Amazon.Controller;

import com.example.Amazon.Dto.UserDto;
import com.example.Amazon.Entity.AuthenticateUser;
import com.example.Amazon.Entity.User;
import com.example.Amazon.Service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
public class UserController {
    @Autowired
    UserService userService;

    @PostMapping("/AddUser")
    public UserDto addUser(@RequestBody User user){
        return userService.addUser(user);
    }

    @GetMapping("/listuser")
    public List<UserDto> getAllUser(){
        return userService.getAllUser();
    }
    @GetMapping("/profile")
    public UserDto profile(HttpSession session){
        UserDto userDto= (UserDto) session.getAttribute("loggedUser");
        if(userDto==null){
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Not logged in!");
        }
        return  userService.profile(userDto);
    }

    @GetMapping("/finduserByUsername/{username}")
    public UserDto finduserByUsername(@PathVariable("username") String username){
        return userService.finduserByUsername(username);
    }

    @GetMapping("/authenticateUser/{username}/{password}")
    public String authenticateUser(@PathVariable("username") String username,
                                   @PathVariable("password") String password, HttpSession session){
        if(!userService.userIsPresent(username)){
            return "User Not Found.......................................";
        }
        AuthenticateUser authenticateUser = new AuthenticateUser();
        authenticateUser.setUsername(username);
        authenticateUser.setPassword(password);

        if(userService.authenticateUser(authenticateUser)){
            UserDto loggedUser=userService.finduserByUsername(authenticateUser.getUsername());
            session.setAttribute("loggedUser",loggedUser);
            return "Login Completed.....................................";
        }
        return "Incorrect Password........................................";
    }

    @GetMapping("/updatepassword/OTPSENDING/{username}/{password}")
    public String updatepasswordSENDINGOTP(@PathVariable("username") String username,
                                           @PathVariable("password") String password) {
        if(!userService.userIsPresent(username)){
            return "User Not Found.............................................";
        }
        AuthenticateUser authenticateUser = new AuthenticateUser();
        authenticateUser.setUsername(username);
        authenticateUser.setPassword(password);
        return userService.updatepassword(authenticateUser);
    }

    @GetMapping("/enterOTP/{phone}/{newpassword}/{otp}")
    public String enterOTP(@PathVariable("phone") String phone,
                           @PathVariable("newpassword") String newpassword,
                           @PathVariable("otp") String otp ){
        return userService.enterOTP(phone, newpassword, otp);
    }

    @DeleteMapping("/deleteuser/{username}/{password}")
    public String deleteUser(@PathVariable("username") String username,
                             @PathVariable("password") String password){
        if(!userService.userIsPresent(username)){
            return "User Not Found.............................................";
        }
        AuthenticateUser authenticateUser = new AuthenticateUser();
        authenticateUser.setUsername(username);
        authenticateUser.setPassword(password);
        return userService.deleteUser(authenticateUser);
    }
    @PostMapping("/logout")
    public String logout(HttpSession session){
        return userService.logout(session);
    }
}