package com.example.Amazon.Service;

import com.example.Amazon.Entity.Cart;
import com.example.Amazon.Entity.Product;
import com.example.Amazon.Entity.User;
import com.example.Amazon.Reposetory.CartRepo;
import com.example.Amazon.Reposetory.ProductRepo;
import com.example.Amazon.Reposetory.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CartService {
    @Autowired
    CartRepo cartRepo;
    @Autowired
    ProductRepo productRepo;
    @Autowired
    UserRepo userRepo;

    public String addToCart(int productid, int userid, int quantity) {
        Optional<Product> optionalProduct = productRepo.findById(productid);
        Product product = optionalProduct.get();
        Optional<User> optionalUser = userRepo.findById(userid);
        User user = optionalUser.get();
        if (quantity <= product.getStock()) {
            Cart cart = new Cart();
            cart.setUserid(user.getUserid());
            cart.setProductid(product.getId());
            cart.setName(product.getName());
            cart.setPrice(product.getPrice());
            cart.setQuantity(quantity);
            cartRepo.save(cart);
            return "Item Added To Cart...................................................";
        }
        return "INSUFFICIENT STOCK.................................................";
    }

    public List<Cart> findCartByUser(int userid) {
        return cartRepo.findAllByUserid(userid);
    }

    public double totalCartCost(int userid) {
        List<Cart> carts = cartRepo.findAllByUserid(userid);
        double total = 0;
        for (Cart cart : carts) {
            double price = cart.getPrice() * cart.getQuantity();
            total += price;
        }
        return total;
    }

    public String removeItem(int userid, int productid) {
        Cart cart = cartRepo.findByUseridAndProductid(userid, productid);
        cart.setQuantity(cart.getQuantity() - 1);
        cartRepo.save(cart);
        return "ONE ITEM REMOVED>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>....";
    }

    public String removeAllItem(int userid) {
        List<Cart> carts = cartRepo.findAllByUserid(userid);
        for (Cart cart : carts) {
            cartRepo.delete(cart);
        }
        return "DELETED ALL ITEM IN YOUR CART................................................";
    }
}
