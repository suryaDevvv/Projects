package com.example.Amazon.Mapper;

import com.example.Amazon.Dto.ProductDto;
import com.example.Amazon.Entity.Product;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ProductMapper {
    ProductDto toDto(Product product);
    Product toEntity(ProductDto productDto);
}
