package com.example.Amazon.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
@Service
public class OtpService {
    private Map<String, OtpInfo> otpStore = new HashMap<>();
    private static final int OTP_VALIDITY_MINUTES = 5;

    private static class OtpInfo {
        String otp;
        LocalDateTime expiry;

        OtpInfo(String otp, LocalDateTime expiry) {
            this.otp = otp;
            this.expiry = expiry;
        }
    }

    @Autowired
    private SmsService smsService;

    public void generateOtpForPhone(String phoneNumber) {
        String otp = String.valueOf(100000 + new Random().nextInt(900000)); // 6-digit OTP
        LocalDateTime expiry = LocalDateTime.now().plusMinutes(OTP_VALIDITY_MINUTES);
        otpStore.put(phoneNumber, new OtpInfo(otp, expiry));

        String messageBody = "Your OTP is: " + otp + ". It is valid for " + OTP_VALIDITY_MINUTES + " minutes.";

        // Send real SMS via Twilio
        smsService.sendSms(phoneNumber, messageBody);
    }
    public boolean authenticateOtp(String phoneNumber, String otp) {
        if (!otpStore.containsKey(phoneNumber)) {
            return false;
        }
        OtpInfo otpInfo = otpStore.get(phoneNumber);
        if (otpInfo.expiry.isBefore(LocalDateTime.now())) {
            otpStore.remove(phoneNumber); // OTP expired, clean up
            return false;
        }
        boolean isValid = otpInfo.otp.equals(otp);
        if (isValid) {
            otpStore.remove(phoneNumber); // OTP used, clean up
        }
        return isValid;
    }
}
