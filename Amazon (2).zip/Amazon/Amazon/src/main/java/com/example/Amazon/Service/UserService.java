package com.example.Amazon.Service;

import com.example.Amazon.Dto.UserDto;
import com.example.Amazon.Entity.AuthenticateUser;
import com.example.Amazon.Entity.User;
import com.example.Amazon.Mapper.UserMapper;
import com.example.Amazon.Reposetory.UserRepo;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    @Autowired
    UserRepo userRepo;

    @Autowired
    UserMapper userMapper;

    @Autowired
    OtpService otpService;

    public UserDto addUser(User user) {
        userRepo.save(user);
        return userMapper.toDto(user);
    }

    public List<UserDto> getAllUser() {
        return userRepo.findAll().stream().map(user -> userMapper.toDto(user)).toList();
    }

    public UserDto finduserByUsername(String username) {
        Optional<User> optionalUser = userRepo.findByUsername(username);

        if (optionalUser.isPresent()) {
            return userMapper.toDto(optionalUser.get());
        } else {
            return null;
        }
    }


    public boolean authenticateUser(AuthenticateUser authenticateUser) {
        Optional<User> optionalUser = userRepo.findByUsername(authenticateUser.getUsername());
        User user = optionalUser.get();
        String password = user.getPassword();
        String commingpassword = authenticateUser.getPassword();
        return password.equals(commingpassword);
    }

    public boolean userIsPresent(String username) {
        return userRepo.existsByUsername(username);
    }

    public String updatepassword(AuthenticateUser authenticateUser) {
        Optional<User> optionalUser = userRepo.findByUsername(authenticateUser.getUsername());
        User user = optionalUser.get();
        if (authenticateUser(authenticateUser)) {
            otpService.generateOtpForPhone(user.getPhoneno());
            return "OTP SENDED";
        }
        return "Incorrect old Password..............................................";
    }

    public String deleteUser(AuthenticateUser authenticateUser) {
        if (authenticateUser(authenticateUser)) {
            Optional<User> optionalUser = userRepo.findByUsername(authenticateUser.getUsername());
            User user = optionalUser.get();
            userRepo.deleteById(user.getUserid());
            return "DELETED.......................................................";
        }
        return "Password Incorrect.................................................";
    }

    public String enterOTP(String phone, String newpassword, String otp) {
        if (otpService.authenticateOtp(phone, otp)) {
            Optional<User> optionalUser = userRepo.findByPhoneno(phone);
            User user = optionalUser.get();
            user.setPassword(newpassword);
            userRepo.save(user);
            return "PASSWORD CHANGED>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.";
        }
        return "ENTER CORRECT OTP>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.";
    }

    public String logout(HttpSession session) {
        session.invalidate();
        return " logged out";
    }

    public UserDto profile(UserDto userDto) {
        return userDto;
    }
}