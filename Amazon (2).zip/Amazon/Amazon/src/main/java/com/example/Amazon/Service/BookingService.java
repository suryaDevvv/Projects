package com.example.Amazon.Service;

import com.example.Amazon.Entity.AuthenticateUser;
import com.example.Amazon.Entity.Booking;
import com.example.Amazon.Entity.Product;
import com.example.Amazon.Entity.User;
import com.example.Amazon.Reposetory.BookingRepo;
import com.example.Amazon.Reposetory.ProductRepo;
import com.example.Amazon.Reposetory.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookingService {
    @Autowired
    BookingRepo bookingRepo;
    @Autowired
    UserRepo userRepo;
    @Autowired
    ProductRepo productRepo;
    @Autowired
    UserService userService;

    public String bookItem(int userid, int productid, int count) {
        Optional<User> optionalUser=userRepo.findById(userid);
        User user=optionalUser.get();
        Optional<Product> optionalProduct=productRepo.findById(productid);
        Product product=optionalProduct.get();
        AuthenticateUser authenticateUser=new AuthenticateUser();
        authenticateUser.setUsername(user.getUsername());
        authenticateUser.setPassword(user.getPassword());
        if(userService.authenticateUser(authenticateUser)) {
            if(count<=product.getStock()) {
                Booking booking = new Booking();
                booking.setUserid(user.getUserid());
                booking.setProductid(product.getId());
                booking.setAddress(user.getAddress());
                booking.setUsername(user.getUsername());
                booking.setPhoneno(user.getPhoneno());
                booking.setProductname(product.getName());
                booking.setPrice(product.getPrice());
                booking.setQuantity(count);
                booking.setTotalprice(product.getPrice() * count);
                bookingRepo.save(booking);
                product.setStock(product.getStock() - count);
                productRepo.save(product);
                return "ORDER PLACED.............................................................";
            }
            else {
                return "LESS STOCK ..................................................................";
            }
        }
        return "INCORRECT PASSWORD...........................................................";
    }

    public List<Booking> showAllOrder(int userid) {
        List<Booking> bookings=bookingRepo.findByUserid(userid);
        return bookings;
    }

    public String deleteOrder(int bookingid, String password) {
        Optional<Booking> optionalBooking=bookingRepo.findById(bookingid);
        Booking booking=optionalBooking.get();
        Optional<User> optionalUser=userRepo.findById(booking.getUserid());
        User user=optionalUser.get();
        AuthenticateUser authenticateUser=new AuthenticateUser();
        authenticateUser.setPassword(password);
        authenticateUser.setUsername(user.getUsername());
        if(userService.authenticateUser(authenticateUser)){
            Optional<Product> optionalProduct=productRepo.findById(booking.getProductid());
            Product product=optionalProduct.get();
            product.setStock(booking.getQuantity()+product.getStock());
            productRepo.save(product);
            bookingRepo.deleteById(bookingid);
            return "Booking Deleted";
        }
        return "Password Incorrect";
    }

}