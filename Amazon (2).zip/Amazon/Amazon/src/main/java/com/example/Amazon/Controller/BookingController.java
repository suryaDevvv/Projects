package com.example.Amazon.Controller;

import com.example.Amazon.Dto.UserDto;
import com.example.Amazon.Entity.Booking;
import com.example.Amazon.Service.BookingService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class BookingController {
    @Autowired
    BookingService bookingService;

    @GetMapping("bookitem/{productid}/{count}")
    public String bookItem(@PathVariable("productid") int productid, @PathVariable("count") int count, HttpSession session){
        UserDto userDto= (UserDto) session.getAttribute("loggedUser");
        if(userDto==null){
            return "NOT loGGED";
        }
        return bookingService.bookItem(userDto.getUserid(),productid,count);
    }

    @GetMapping("showallorder")
    public List<Booking> showAllOrder(HttpSession session){
        UserDto userDto= (UserDto) session.getAttribute("loggedUser");

        return bookingService.showAllOrder(userDto.getUserid());
    }
    @DeleteMapping("deletebooking/{bookingid}/{password}")
    public String deleteOrder(@PathVariable("bookingid") int bookingid,@PathVariable("password") String password){
        return bookingService.deleteOrder(bookingid,password);
    }

}