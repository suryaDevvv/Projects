package com.example.Amazon.Dto;


public class UserDto {
    private int userid;
    private String username;
    private String address;
    private String phoneno;

    public UserDto(int userid, String phoneno, String address, String username) {
        this.userid = userid;
        this.phoneno = phoneno;
        this.address = address;
        this.username = username;
    }

    public UserDto() {
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPhoneno() {
        return phoneno;
    }

    public void setPhoneno(String phoneno) {
        this.phoneno = phoneno;
    }
}
