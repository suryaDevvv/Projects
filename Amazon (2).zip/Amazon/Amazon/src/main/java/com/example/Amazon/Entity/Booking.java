package com.example.Amazon.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;

import java.util.Objects;
import java.util.Random;

@Entity
public class Booking {
    @Id
    private int bookingid;
    private int userid;
    private int productid;
    private String address;
    private String username;
    private String phoneno;
    private String productname;
    private double price;
    private int quantity;
    private double totalprice;

    @PrePersist
    public void generateBookingId() {
        if (this.bookingid == 0) {
            Random random = new Random();
            this.bookingid = 100000 + random.nextInt(900000); // Generates a 6-digit random ID
        }
    }
    public Booking(int bookingid, double totalprice, int quantity, double price, String productname, String phoneno, String address, String username, int productid, int userid) {
        this.bookingid = bookingid;
        this.totalprice = totalprice;
        this.quantity = quantity;
        this.price = price;
        this.productname = productname;
        this.phoneno = phoneno;
        this.address = address;
        this.username = username;
        this.productid = productid;
        this.userid = userid;
    }

    public Booking() {
    }

    public int getBookingid() {
        return bookingid;
    }

    public void setBookingid(int bookingid) {
        this.bookingid = bookingid;
    }

    public double getTotalprice() {
        return totalprice;
    }

    public void setTotalprice(double totalprice) {
        this.totalprice = totalprice;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

    public String getPhoneno() {
        return phoneno;
    }

    public void setPhoneno(String phoneno) {
        this.phoneno = phoneno;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getProductid() {
        return productid;
    }

    public void setProductid(int productid) {
        this.productid = productid;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Booking booking = (Booking) o;
        return bookingid == booking.bookingid && userid == booking.userid && productid == booking.productid && Double.compare(price, booking.price) == 0 && quantity == booking.quantity && Double.compare(totalprice, booking.totalprice) == 0 && Objects.equals(address, booking.address) && Objects.equals(username, booking.username) && Objects.equals(phoneno, booking.phoneno) && Objects.equals(productname, booking.productname);
    }

    @Override
    public int hashCode() {
        return Objects.hash(bookingid, userid, productid, address, username, phoneno, productname, price, quantity, totalprice);
    }
}
