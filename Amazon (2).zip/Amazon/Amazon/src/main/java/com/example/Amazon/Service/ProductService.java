package com.example.Amazon.Service;

import com.example.Amazon.Dto.ProductDto;
import com.example.Amazon.Entity.Product;
import com.example.Amazon.Mapper.ProductMapper;
import com.example.Amazon.Reposetory.ProductRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {
    @Autowired
    ProductRepo productRepo;
    @Autowired
    ProductMapper productMapper;

    public Product addProduct(Product product) {
        productRepo.save(product);
        return product;
    }

    public List<Product> getAllProduct() {
        return productRepo.findAll();
    }

    public List<ProductDto> findById(int id) {
        return productRepo.findById(id).stream().map(product -> productMapper.toDto(product)).toList();
    }

    public Product updateproduct(int id, Product product) {
        Optional<Product> optionalProduct = productRepo.findById(id);
        Product oldproduct=optionalProduct.get();
        oldproduct.setName(product.getName());
        oldproduct.setPrice(product.getPrice());
        oldproduct.setStock(product.getStock());
        productRepo.save(oldproduct);
        return product;
    }

    public Product updatePrice(int id, double newprice) {
        Optional<Product> optionalProduct=productRepo.findById(id);
        Product oldproduct=optionalProduct.get();
        oldproduct.setPrice(newprice);
        productRepo.save(oldproduct);
        return oldproduct;
    }

    public Product updateStock(int id, int newstock) {
        Optional<Product> optionalProduct=productRepo.findById(id);
        Product oldproduct=optionalProduct.get();
        oldproduct.setStock(newstock);
        productRepo.save(oldproduct);
        return oldproduct;
    }

    public Product deleteProduct(int id) {
        Optional<Product> optionalProduct=productRepo.findById(id);
        Product deletingproduct=optionalProduct.get();
        productRepo.delete(deletingproduct);
        return deletingproduct;
    }
}