package com.example.Amazon.Reposetory;

import com.example.Amazon.Entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookingRepo extends JpaRepository<Booking,Integer> {
    List<Booking> findByUserid(int userid);
}
