package com.example.Amazon.Controller;

import com.example.Amazon.Dto.ProductDto;
import com.example.Amazon.Entity.Product;
import com.example.Amazon.Service.ProductService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ProductController {
    @Autowired
    ProductService productService;

    @GetMapping("/allproduct")
    public List<Product> getAllProduct(){
        return productService.getAllProduct();
    }
    @GetMapping("/product/{id}")
    public List<ProductDto> findById(@PathVariable("id") int id){
        return productService.findById(id);
    }
    @PostMapping("/Product/add")
    public Product addProduct(@RequestBody Product product){
        return productService.addProduct(product);
    }
    @PutMapping("/Product/update/{id}")
    public Product updateproduct(@PathVariable("id") int id,@RequestBody Product product){
        return productService.updateproduct(id,product);
    }
    @PutMapping("/product/updateprice/{id}/{newprice}")
    public Product updatePrice(@PathVariable("id") int id,@PathVariable("newprice") double newprice){
        return productService.updatePrice(id,newprice);
    }
    @PutMapping("/product/updatestock/{id}/{newstock}")
    public Product updateStock(@PathVariable("id") int id,@PathVariable("newstock") int newstock){
        return productService.updateStock(id,newstock);
    }
    @DeleteMapping("/deleteproduct/{id}")
    public Product deleteProduct(@PathVariable("id") int id){
        return productService.deleteProduct(id);
    }

}