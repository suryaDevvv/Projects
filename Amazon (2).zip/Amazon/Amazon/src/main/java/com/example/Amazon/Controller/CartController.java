package com.example.Amazon.Controller;

import com.example.Amazon.Dto.UserDto;
import com.example.Amazon.Entity.Cart;
import com.example.Amazon.Reposetory.ProductRepo;
import com.example.Amazon.Service.CartService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class CartController {
    @Autowired
    CartService cartService;



    @GetMapping("/addtocart/{productid}/{quantity}")
    public String  addToCart(@PathVariable("productid") int productid, @PathVariable("quantity") int quantity, HttpSession session){
        UserDto userDto= (UserDto) session.getAttribute("loggedUser");
        if(userDto==null){
            return  " NOt LOGGED";
        }
        return cartService.addToCart(productid,userDto.getUserid(),quantity);
    }

    @GetMapping("/seecart")
    public List<Cart> findCartByUser(HttpSession session){
        UserDto userDto= (UserDto) session.getAttribute("loggedUser");

        return cartService.findCartByUser(userDto.getUserid());
    }

    @GetMapping("/seetotalcostincart")
    public double totalCartCost(HttpSession session){
        UserDto userDto= (UserDto) session.getAttribute("loggedUser");
        return cartService.totalCartCost(userDto.getUserid());
    }

    @GetMapping("/removeitemincart/{productid}")
    public String removeItem(@PathVariable("productid") int productid,HttpSession session){
        UserDto userDto= (UserDto) session.getAttribute("loggedUser");
        return cartService.removeItem(userDto.getUserid(),productid);
    }
    @DeleteMapping("removeallfromcart")
    public String removeAllItem(HttpSession session){
        UserDto userDto= (UserDto) session.getAttribute("loggedUser");

        return cartService.removeAllItem(userDto.getUserid());
    }
}
