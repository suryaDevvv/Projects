package com.example.Amazon.Dto;

import lombok.*;

public class ProductDto {
    private int id;
    private String name;
    private double price;
    private int stock;

    public int getId() {
        return id;
    }

    public ProductDto() {
    }

    public ProductDto(int id, int stock, double price, String name) {
        this.id = id;
        this.stock = stock;
        this.price = price;
        this.name = name;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }
}
