package com.example.Amazon.Reposetory;

import com.example.Amazon.Entity.Cart;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CartRepo extends JpaRepository<Cart,Integer> {
    List<Cart> findAllByUserid(int userid);
    Cart findByUseridAndProductid(int userid,int productid);
}
