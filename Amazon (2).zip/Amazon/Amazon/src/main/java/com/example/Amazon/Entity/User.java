package com.example.Amazon.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;

import java.util.Random;

@Entity
public class User {
    @Id
    private int userid;
    private String username;
    private String password;
    private String address;
    private String phoneno;
    @PrePersist
    public void generateBillNo() {
        if (this.userid == 0) {
            Random random = new Random();
            this.userid = 100000 + random.nextInt(900000);
        }
    }

    public User(int userid, String phoneno, String address, String password, String username) {
        this.userid = userid;
        this.phoneno = phoneno;
        this.address = address;
        this.password = password;
        this.username = username;
    }

    public User() {
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public String getPhoneno() {
        return phoneno;
    }

    public void setPhoneno(String phoneno) {
        this.phoneno = phoneno;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
