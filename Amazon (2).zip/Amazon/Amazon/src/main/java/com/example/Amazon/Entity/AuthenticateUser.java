package com.example.Amazon.Entity;

import java.util.Objects;

public class AuthenticateUser {
    private String username;
    private String password;

    public AuthenticateUser(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public AuthenticateUser() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        AuthenticateUser that = (AuthenticateUser) o;
        return Objects.equals(username, that.username) && Objects.equals(password, that.password);
    }

    @Override
    public int hashCode() {
        return Objects.hash(username, password);
    }
}
