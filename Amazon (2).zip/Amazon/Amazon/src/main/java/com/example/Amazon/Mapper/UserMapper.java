package com.example.Amazon.Mapper;

import com.example.Amazon.Dto.UserDto;
import com.example.Amazon.Entity.User;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface UserMapper {
    UserDto toDto(User user);
    User toEntity(UserDto userDto);
}
