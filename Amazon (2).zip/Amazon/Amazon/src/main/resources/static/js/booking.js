document.addEventListener("DOMContentLoaded", function () {
    loadOrders();
});

function loadOrders() {
    fetch("http://localhost:8080/showallorder", {
        method: "GET",
        credentials: "include",
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Failed to fetch orders.");
        }
        return response.json();
    })
    .then(orders => {
        const orderList = document.getElementById("order-list");
        orderList.innerHTML = "";

        if (orders.length === 0) {
            orderList.innerHTML = `
                <div class="col-12">
                    <div class="empty-orders-message">
                        <h3>No orders found</h3>
                        <p>You haven't placed any orders yet!</p>
                        <a href="products.html" class="btn btn-primary">Start Shopping</a>
                    </div>
                </div>
            `;
            return;
        }

        orders.forEach((order, index) => {
            const imageName = `product${order.productid}.${getImageExtension(order.productid)}`;
            const orderCard = `
                <div class="col-md-6 col-lg-4">
                    <div class="order-card">
                        <div class="order-header">
                            <div class="order-id">Order #${order.bookingid}</div>
                            <div class="order-status">✅ Confirmed</div>
                        </div>

                        <img src="images/${imageName}" class="order-img" alt="${order.productname}">

                        <div class="order-details">
                            <div class="product-name">${order.productname}</div>
                            <div class="product-price">Unit Price: ₹${order.price}</div>
                            <div class="product-quantity">Quantity: ${order.quantity}</div>
                            <div class="total-price">Total: ₹${order.totalprice.toFixed(2)}</div>
                        </div>

                        <div class="shipping-info">
                            <div class="customer-name">👤 ${order.username}</div>
                            <div class="customer-phone">📞 ${order.phoneno}</div>
                            <div class="customer-address">📍 ${order.address}</div>
                        </div>

                        <div class="order-actions">
                            <button class="btn btn-danger btn-sm" onclick="cancelOrder(${order.bookingid})">
                                🗑️ Cancel Order
                            </button>
                        </div>
                    </div>
                </div>
            `;
            orderList.innerHTML += orderCard;
        });

        calculateTotalOrders(orders);
    })
    .catch(error => {
        console.error("Error loading orders:", error);
        document.getElementById("order-list").innerHTML = `
            <div class="col-12">
                <div class="error-message">
                    <h3>Error loading orders</h3>
                    <p>Please try refreshing the page.</p>
                    <button class="btn btn-primary" onclick="loadOrders()">Retry</button>
                </div>
            </div>
        `;
    });
}

function calculateTotalOrders(orders) {
    const totalAmount = orders.reduce((sum, order) => sum + order.totalprice, 0);
    const totalItems = orders.reduce((sum, order) => sum + order.quantity, 0);

    document.getElementById("total-orders").innerText = orders.length;
    document.getElementById("total-amount").innerText = `₹${totalAmount.toFixed(2)}`;
    document.getElementById("total-items").innerText = totalItems;
}

function cancelOrder(bookingid) {
    const password = prompt("Please enter your password to cancel this order:");

    if (!password) {
        return; // User cancelled the prompt
    }

    fetch(`http://localhost:8080/deletebooking/${bookingid}/${encodeURIComponent(password)}`, {
        method: "DELETE",
        credentials: "include",
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Failed to cancel order.");
        }
        return response.text();
    })
    .then(result => {
        if (result.includes("Password Incorrect")) {
            alert("❌ Incorrect password. Order not cancelled.");
        } else {
            alert("✅ Order cancelled successfully!");
            loadOrders(); // Reload orders
        }
    })
    .catch(error => {
        console.error("Error cancelling order:", error);
        alert("❌ Could not cancel order. Please try again.");
    });
}

function bookSingleItem(productid, quantity = 1) {
    fetch(`http://localhost:8080/bookitem/${productid}/${quantity}`, {
        method: "GET",
        credentials: "include",
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Failed to book item.");
        }
        return response.text();
    })
    .then(result => {
        if (result.includes("ORDER PLACED")) {
            alert("✅ Order placed successfully!");
            loadOrders(); // Reload orders to show the new one
        } else if (result.includes("LESS STOCK")) {
            alert("❌ Insufficient stock for this item.");
        } else if (result.includes("NOT loGGED")) {
            alert("❌ Please log in to place an order.");
            window.location.href = "login.html";
        } else {
            alert("❌ Could not place order: " + result);
        }
    })
    .catch(error => {
        console.error("Error booking item:", error);
        alert("❌ Could not place order. Please try again.");
    });
}

function getImageExtension(index) {
    const extensions = ["png", "webp", "webp", "jpg", "jpeg", "webp"];
    return extensions[(index - 1) % extensions.length];
}

// Function to refresh orders
function refreshOrders() {
    document.getElementById("order-list").innerHTML = `
        <div class="col-12">
            <div class="empty-orders-message">
                <h3>Loading orders...</h3>
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>
        </div>
    `;
    loadOrders();
}