console.log("✅ Cart.js loaded successfully!");

document.addEventListener("DOMContentLoaded", function () {
    console.log("DOM loaded, starting cart load...");
    loadCart();
});

function loadCart() {
    console.log("Loading cart...");

    fetch("http://localhost:8080/seecart", {
        method: "GET",
        credentials: "include",
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => {
        console.log("Response received:", response.status, response.ok);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(cartItems => {
        console.log("Cart items received:", cartItems);
        displayCartItems(cartItems);
        loadTotalCost();
    })
    .catch(error => {
        console.error("Error loading cart:", error);
        const cartContainer = document.getElementById("cart-container");
        if (cartContainer) {
            cartContainer.innerHTML = `
                <div class="col-12">
                    <div class="error-message">
                        <h3>Error loading cart</h3>
                        <p>Error: ${error.message}</p>
                        <button class="btn btn-primary" onclick="loadCart()">Retry</button>
                    </div>
                </div>
            `;
        }
    });
}

function displayCartItems(cartItems) {
    const cartContainer = document.getElementById("cart-container");

    if (!cartContainer) {
        console.error("cart-container element not found!");
        return;
    }

    cartContainer.innerHTML = "";

    if (cartItems.length === 0) {
        cartContainer.innerHTML = `
            <div class="col-12">
                <div class="empty-cart-message">
                    <h3>Your cart is empty</h3>
                    <p>Add some products to get started!</p>
                    <a href="products.html" class="btn btn-primary">Continue Shopping</a>
                </div>
            </div>
        `;
        return;
    }

    cartItems.forEach((item, index) => {
        console.log(`Processing item ${index}:`, item);

        const imageName = `product${item.productid}.${getImageExtension(item.productid)}`;
        const cartItemHTML = `
            <div class="col-md-4">
                <div class="cart-card">
                    <img src="images/${imageName}" class="cart-img" alt="${item.name}">
                    <div class="cart-id">${item.productid}</div>
                    <div class="cart-name">${item.name}</div>
                    <div class="cart-price">₹${item.price}</div>
                    <div class="cart-quantity">Quantity: ${item.quantity}</div>
                    <div class="cart-total">Total: ₹${(item.price * item.quantity).toFixed(2)}</div>
                    <div class="cart-actions">
                        <button class="btn btn-danger btn-sm" onclick="removeItem(${item.productid})">
                            Remove
                        </button>
                    </div>
                </div>
            </div>
        `;
        cartContainer.innerHTML += cartItemHTML;
    });
}

function loadTotalCost() {
    console.log("Loading total cost...");

    fetch("http://localhost:8080/seetotalcostincart", {
        method: "GET",
        credentials: "include",
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(totalCost => {
        console.log("Total cost received:", totalCost);
        const totalElement = document.getElementById("total-cost");
        if (totalElement) {
            totalElement.innerText = `₹${totalCost.toFixed(2)}`;
        }
    })
    .catch(error => {
        console.error("Error loading total cost:", error);
        const totalElement = document.getElementById("total-cost");
        if (totalElement) {
            totalElement.innerText = "Error loading total";
        }
    });
}

function removeItem(productid) {
    console.log("Removing item:", productid);

    fetch(`http://localhost:8080/removeitemincart/${productid}`, {
        method: "GET",
        credentials: "include",
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.text();
    })
    .then(result => {
        console.log("Remove result:", result);
        alert("✅ Item removed from cart!");
        loadCart();
    })
    .catch(error => {
        console.error("Error removing item:", error);
        alert("❌ Could not remove item.");
    });
}

function clearCart() {
    if (confirm("Are you sure you want to remove all items from your cart?")) {
        fetch("http://localhost:8080/removeallfromcart", {
            method: "DELETE",
            credentials: "include",
            headers: {
                "Content-Type": "application/json"
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.text();
        })
        .then(result => {
            console.log("Clear cart result:", result);
            alert("✅ Cart cleared!");
            loadCart();
        })
        .catch(error => {
            console.error("Error clearing cart:", error);
            alert("❌ Could not clear cart.");
        });
    }
}

// NEW FUNCTION: Book all items in cart
function bookAllCartItems() {
    console.log("Booking all cart items...");

    // First, get the current cart items
    fetch("http://localhost:8080/seecart", {
        method: "GET",
        credentials: "include",
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(cartItems => {
        if (cartItems.length === 0) {
            alert("❌ Your cart is empty!");
            return;
        }

        // Show confirmation
        const totalItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);
        const confirmMessage = `Are you sure you want to place orders for all ${totalItems} items in your cart?`;

        if (!confirm(confirmMessage)) {
            return;
        }

        // Book each item individually
        const bookingPromises = cartItems.map(item =>
            bookSingleItem(item.productid, item.quantity)
        );

        Promise.all(bookingPromises)
            .then(results => {
                console.log("All booking results:", results);
                alert("✅ All orders placed successfully!");

                // Clear the cart after successful booking
                clearCartAfterBooking();

                // Redirect to orders page
                window.location.href = "booking.html";
            })
            .catch(error => {
                console.error("Error booking some items:", error);
                alert("⚠️ Some orders may not have been placed. Please check your orders.");
                window.location.href = "booking.html";
            });
    })
    .catch(error => {
        console.error("Error getting cart items:", error);
        alert("❌ Could not retrieve cart items.");
    });
}

// Helper function to book a single item (returns a promise)
function bookSingleItem(productid, quantity = 1) {
    return fetch(`http://localhost:8080/bookitem/${productid}/${quantity}`, {
        method: "GET",
        credentials: "include",
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Failed to book item.");
        }
        return response.text();
    })
    .then(result => {
        if (result.includes("ORDER PLACED")) {
            return { success: true, productid, quantity, message: result };
        } else if (result.includes("LESS STOCK")) {
            throw new Error(`Insufficient stock for product ${productid}`);
        } else if (result.includes("NOT loGGED")) {
            alert("❌ Please log in to place an order.");
            window.location.href = "login.html";
            throw new Error("Not logged in");
        } else {
            throw new Error(`Could not place order for product ${productid}: ${result}`);
        }
    });
}

// Helper function to clear cart after successful booking
function clearCartAfterBooking() {
    fetch("http://localhost:8080/removeallfromcart", {
        method: "DELETE",
        credentials: "include",
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => {
        console.log("Cart cleared after booking");
    })
    .catch(error => {
        console.error("Error clearing cart after booking:", error);
    });
}

function getImageExtension(index) {
    const extensions = ["png", "webp", "webp", "jpg", "jpeg", "webp"];
    return extensions[(index - 1) % extensions.length];
}