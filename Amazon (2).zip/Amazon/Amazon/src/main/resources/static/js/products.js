document.addEventListener("DOMContentLoaded", () => {
    loadProducts();
    loadUserProfile();
});

function loadProducts() {
    fetch("http://localhost:8080/allproduct")
        .then(response => {
            if (!response.ok) {
                throw new Error("Failed to fetch products.");
            }
            return response.json();
        })
        .then(products => {
            const productList = document.getElementById("product-list");
            productList.innerHTML = ""; // Clear existing content

            products.forEach((product, index) => {
                const imageName = `product${index + 1}.${getImageExtension(index + 1)}`;
                const productCard = `
                    <div class="col-md-4">
                        <div class="product-card">
                            <img src="images/${imageName}" class="product-img" alt="${product.name}">
                            <div class="product-id">ID: ${product.id}</div>
                            <div class="product-name">${product.name}</div>
                            <div class="product-price">₹${product.price}</div>
                            <div class="product-stock">In Stock: ${product.stock}</div>

                            <!-- Quantity Selection -->
                            <div class="quantity-section mt-2">
                                <label for="quantity-${product.id}" class="form-label">Quantity:</label>
                                <input type="number" id="quantity-${product.id}" class="form-control quantity-input"
                                       value="1" min="1" max="${product.stock}">
                            </div>

                            <!-- Action Buttons -->
                            <div class="product-actions mt-3">
                                <button class="btn btn-primary btn-sm me-2" onclick="addToCart(${product.id})">
                                    🛒 Add to Cart
                                </button>
                                <button class="btn btn-success btn-sm" onclick="buyNow(${product.id})">
                                    ⚡ Buy Now
                                </button>
                            </div>
                        </div>
                    </div>
                `;
                productList.innerHTML += productCard;
            });
        })
        .catch(error => {
            console.error("Error loading products:", error);
            document.getElementById("product-list").innerHTML = `
                <div class="col-12">
                    <div class="error-message">
                        <h3>Error loading products</h3>
                        <p>Please try refreshing the page.</p>
                        <button class="btn btn-primary" onclick="loadProducts()">Retry</button>
                    </div>
                </div>
            `;
        });
}

function addToCart(productid) {
    const quantityInput = document.getElementById(`quantity-${productid}`);
    const quantity = parseInt(quantityInput.value) || 1;

    if (quantity < 1) {
        alert("❌ Please select a valid quantity.");
        return;
    }

    fetch(`http://localhost:8080/addtocart/${productid}/${quantity}`, {
        method: "GET",
        credentials: "include",
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Failed to add product to cart.");
        }
        return response.text();
    })
    .then(data => {
        console.log("Add to cart result:", data);
        if (data.includes("ADDED TO CART") || data.includes("SUCCESS")) {
            alert(`✅ ${quantity} item(s) added to cart!`);
            // Reset quantity to 1 after adding
            quantityInput.value = 1;
        } else if (data.includes("LESS STOCK")) {
            alert("❌ Insufficient stock for the requested quantity.");
        } else if (data.includes("NOT loGGED")) {
            alert("❌ Please log in to add items to cart.");
            window.location.href = "login.html";
        } else {
            alert("✅ Product added to cart!");
        }
    })
    .catch(error => {
        console.error("Error:", error);
        alert("❌ Could not add product to cart.");
    });
}

function buyNow(productid) {
    const quantityInput = document.getElementById(`quantity-${productid}`);
    const quantity = parseInt(quantityInput.value) || 1;

    if (quantity < 1) {
        alert("❌ Please select a valid quantity.");
        return;
    }

    // Show confirmation dialog
    const productName = document.querySelector(`#quantity-${productid}`).closest('.product-card').querySelector('.product-name').textContent;
    const productPrice = document.querySelector(`#quantity-${productid}`).closest('.product-card').querySelector('.product-price').textContent;

    const confirmMessage = `Are you sure you want to buy:\n\n${productName}\n${productPrice}\nQuantity: ${quantity}`;

    if (!confirm(confirmMessage)) {
        return;
    }

    // Show loading state
    const buyButton = event.target;
    const originalText = buyButton.innerHTML;
    buyButton.innerHTML = '⏳ Processing...';
    buyButton.disabled = true;

    fetch(`http://localhost:8080/bookitem/${productid}/${quantity}`, {
        method: "GET",
        credentials: "include",
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Failed to book item.");
        }
        return response.text();
    })
    .then(result => {
        console.log("Buy now result:", result);

        if (result.includes("ORDER PLACED")) {
            alert("✅ Order placed successfully!");
            // Reset quantity to 1 after purchase
            quantityInput.value = 1;

            // Ask if user wants to view orders
            if (confirm("Would you like to view your orders?")) {
                window.location.href = "booking.html";
            }
        } else if (result.includes("LESS STOCK")) {
            alert("❌ Insufficient stock for the requested quantity.");
        } else if (result.includes("NOT loGGED")) {
            alert("❌ Please log in to place an order.");
            window.location.href = "login.html";
        } else {
            alert("❌ Could not place order: " + result);
        }
    })
    .catch(error => {
        console.error("Error booking item:", error);
        alert("❌ Could not place order. Please try again.");
    })
    .finally(() => {
        // Restore button state
        buyButton.innerHTML = originalText;
        buyButton.disabled = false;
    });
}

function getImageExtension(index) {
    const extensions = ["png", "webp", "webp", "jpg", "jpeg", "webp"];
    return extensions[(index - 1) % extensions.length];
}

// User Profile Functions
function loadUserProfile() {
    // Get user info from your backend profile endpoint
    fetch("http://localhost:8080/profile", {
        method: "GET",
        credentials: "include",
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Failed to get user profile");
        }
        return response.json();
    })
    .then(user => {
        console.log("User profile loaded:", user);
        // Update username in dropdown
        const usernameDisplay = document.getElementById("username-display");
        const usernameHeader = document.getElementById("username-header");

        if (usernameDisplay && user.username) {
            usernameDisplay.textContent = user.username;
        }
        if (usernameHeader && user.username) {
            usernameHeader.textContent = user.username;
        }
    })
    .catch(error => {
        console.log("User not logged in or profile unavailable:", error);
        // If user is not logged in, redirect to login page
        alert("Please log in to access products.");
        window.location.href = "index.html";
    });
}

function viewProfile() {
    // Get current user profile and show details
    fetch("http://localhost:8080/profile", {
        method: "GET",
        credentials: "include",
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Failed to get profile");
        }
        return response.json();
    })
    .then(user => {
        // Show user profile in a modal or alert
        const profileInfo = `
👤 User Profile:

• User ID: ${user.userid}
• Username: ${user.username}
• Phone: ${user.phoneno}
• Address: ${user.address}
        `;
        alert(profileInfo);
    })
    .catch(error => {
        console.error("Error loading profile:", error);
        alert("Could not load profile information.");
    });
}

function logout() {
    if (confirm("Are you sure you want to logout?")) {
        fetch("http://localhost:8080/logout", {
            method: "POST",
            credentials: "include",
            headers: {
                "Content-Type": "application/json"
            }
        })
        .then(response => {
            if (response.ok) {
                return response.text();
            } else {
                throw new Error("Logout failed");
            }
        })
        .then(result => {
            console.log("Logout result:", result);
            alert("✅ Logged out successfully!");
            window.location.href = "index.html";
        })
        .catch(error => {
            console.error("Logout error:", error);
            // Even if there's an error, still redirect to login
            alert("Logged out!");
            window.location.href = "index.html";
        });
    }
}