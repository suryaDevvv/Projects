document.addEventListener("DOMContentLoaded", () => {
    const btn = document.getElementById("registerBtn");
    if (btn) {
        btn.addEventListener("click", register);
    }
});

function register() {
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    const address = document.getElementById("address").value.trim();
    const phoneno = document.getElementById("phoneno").value.trim();

    if (!username || !password || !address || !phoneno) {
        alert("Please fill in all fields!");
        return;
    }

    const user = { username, password, address, phoneno };

    fetch("http://localhost:8080/AddUser", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(user)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error("Failed to register user");
        }
        return response.json();
    })
    .then(data => {
        alert("User registered successfully!");
        // Optionally redirect to login page
        // window.location.href = "login.html";
    })
    .catch(error => {
        console.error("Error:", error);
        alert("Registration failed. Try again.");
    });
}
