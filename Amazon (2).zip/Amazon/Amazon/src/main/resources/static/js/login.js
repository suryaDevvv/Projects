function login() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    fetch(`http://localhost:8080/authenticateUser/${username}/${password}`)
        .then(response => response.text())
        .then(data => {
            document.getElementById("message").textContent = data;

            if (data.includes("Login Completed")) {

                fetch(`http://localhost:8080/finduserByUsername/${username}`)
                    .then(response => response.json())
                    .then(user => {
                        // ✅ Store the userid in localStorage
                        localStorage.setItem("userid", user.id);

                        setTimeout(() => {
                            window.location.href = "products.html";
                        }, 1000);
                    })
                    .catch(err => {
                        console.error("Could not fetch user ID:", err);
                        alert("Login succeeded, but user info could not be loaded.");
                    });
            }
        })
        .catch(error => {
            console.error("Error during login:", error);
            document.getElementById("message").textContent = "Something went wrong.";
        });
}
