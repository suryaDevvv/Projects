const API = "http://127.0.0.1:8000";

// LOAD STATS
async function loadStats() {
    const res = await fetch(`${API}/stats`);
    const data = await res.json();

    document.getElementById("dailyLimit").innerText =
        `Daily Limit: ${data.daily_limit} kWh`;

    document.getElementById("usage").innerText =
        `Current Usage: ${data.daily_usage} kWh`;

    document.getElementById("percent").innerText =
        `Usage Percentage: ${data.usage_percent} %`;

    document.getElementById("excess").innerText =
        `Excess Usage: ${data.excess_usage} kWh`;
}

// LOAD ALERTS
async function loadAlerts() {
    const res = await fetch(`${API}/alerts`);
    const alerts = await res.json();

    const ul = document.getElementById("alerts");
    ul.innerHTML = "";

    alerts.forEach(a => {
        const li = document.createElement("li");
        li.innerText = `${a.timestamp} - ${a.alert_type}: ${a.message}`;
        ul.appendChild(li);
    });
}

// UPDATE BUDGET
async function updateBudget() {
    const amount = document.getElementById("budgetInput").value;

    if (!amount || amount <= 0) {
        alert("Enter valid budget amount");
        return;
    }

    await fetch(`${API}/budget`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount: parseFloat(amount) })
    });

    alert("Budget applied successfully");
}

// AUTO REFRESH
setInterval(() => {
    loadStats();
    loadAlerts();
}, 3000);
