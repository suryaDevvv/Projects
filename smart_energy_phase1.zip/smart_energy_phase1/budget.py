from config import TOTAL_DAYS, AVG_UNIT_COST
from datetime import date

class BudgetEngine:
    def __init__(self):
        self.bimonthly_amount = 1200
        self.total_days = TOTAL_DAYS
        self.current_day = 1

        self.max_units = self.bimonthly_amount / AVG_UNIT_COST
        self.daily_limit = self.max_units / TOTAL_DAYS

        self.daily_usage = 0.0
        self.excess_usage = 0.0

        # ALERT FLAGS
        self.alert_50_sent = False
        self.alert_90_sent = False
        self.alert_100_sent = False

        # 🔒 HARD DAY LOCK
        self.day_locked = False
        self.last_date = date.today()

    def update_usage(self, energy):
        # BEFORE LIMIT
        if not self.day_locked:
            if self.daily_usage + energy < self.daily_limit:
                self.daily_usage += energy
            else:
                # EXACT MOMENT LIMIT IS CROSSED
                self.excess_usage += (self.daily_usage + energy - self.daily_limit)
                self.daily_usage = self.daily_limit
                self.day_locked = True
        else:
            # AFTER LIMIT
            self.excess_usage += energy

        return (self.daily_usage / self.daily_limit) * 100

    def check_new_day(self):
        today = date.today()
        if today != self.last_date:
            self.apply_excess_to_future_days()
            self.reset_day()
            self.last_date = today

    def reset_day(self):
        self.daily_usage = 0
        self.excess_usage = 0
        self.current_day += 1

        # RESET ALERTS
        self.alert_50_sent = False
        self.alert_90_sent = False
        self.alert_100_sent = False
        self.day_locked = False

    def apply_excess_to_future_days(self):
        remaining_days = self.total_days - self.current_day
        if remaining_days <= 0:
            return

        remaining_units = self.max_units - (
            self.daily_limit + self.excess_usage
        )
        self.daily_limit = max(remaining_units / remaining_days, 0.01)
