from pydantic import BaseModel

class EnergyData(BaseModel):
    power: float
    energy: float
