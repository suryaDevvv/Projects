import requests
import time

URL = "http://127.0.0.1:8000/energy"

# EXTREMELY HIGH POWER (FAST ALERT TEST)
HIGH_POWER = 20000  # 20 kW (industrial-level load)

while True:
    power = HIGH_POWER

    # artificially high energy per second
    energy = power / 1000 / 60   # kWh per second (60x faster than real)

    res = requests.post(URL, json={
        "power": power,
        "energy": energy
    })

    print("🔥 FAST TEST | Power:", power, "W | Energy:", energy, "kWh")

    time.sleep(1)
