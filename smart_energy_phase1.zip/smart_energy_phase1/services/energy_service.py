from budget import BudgetEngine
from alerts import log_alert
from database.db import get_connection
from datetime import datetime, timedelta
from sms import send_sms
from config import USER_PHONE_NUMBER   # make sure this exists in config.py

engine = BudgetEngine()
last_db_write = datetime.now()

def process_energy(power, energy):
    global last_db_write

    # Check for new day & apply excess logic
    engine.check_new_day()

    # Update usage every second
    percent = engine.update_usage(energy)

    # ---------------- INFO ALERT (50%) ----------------
    if percent >= 50 and not engine.alert_50_sent:
        log_alert("INFO", "50% of daily usage reached")
        engine.alert_50_sent = True

    # ---------------- WARNING ALERT (90%) ----------------
    if percent >= 90 and not engine.alert_90_sent:
        log_alert("WARNING", "90% of daily usage reached")

        # SEND SMS ONCE
        send_sms(
            USER_PHONE_NUMBER,
            "⚠️ Warning: 90% of today's electricity limit has been used."
        )

        engine.alert_90_sent = True

    # ---------------- CRITICAL ALERT (100%) ----------------
    if percent >= 100 and not engine.alert_100_sent:
        log_alert("CRITICAL", "Daily limit exceeded. Excess redirected.")

        # SEND SMS ONCE
        send_sms(
            USER_PHONE_NUMBER,
            "🚨 Alert: Daily electricity limit exceeded. Extra usage will be adjusted from upcoming days."
        )

        engine.alert_100_sent = True

    # ---------------- DATABASE WRITE (EVERY 10 MINUTES) ----------------
    if datetime.now() - last_db_write >= timedelta(minutes=10):
        db = get_connection()
        cursor = db.cursor()
        cursor.execute(
            """
            INSERT INTO usage_data
            (timestamp, power, energy, daily_usage, usage_percent)
            VALUES (%s,%s,%s,%s,%s)
            """,
            (datetime.now(), power, energy, engine.daily_usage, percent)
        )
        db.commit()
        db.close()
        last_db_write = datetime.now()

    # ---------------- RESPONSE TO DASHBOARD / APP ----------------
    return {
        "daily_usage": round(engine.daily_usage, 4),
        "excess_usage": round(engine.excess_usage, 4),
        "daily_limit": round(engine.daily_limit, 4),
        "usage_percent": round(percent, 2)
    }
