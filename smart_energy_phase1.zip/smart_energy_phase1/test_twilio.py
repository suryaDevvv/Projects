from sms import send_sms
from config import USER_PHONE_NUMBER

send_sms(
    USER_PHONE_NUMBER,
    "✅ Test SMS from Smart Energy Application (Twilio)"
)
