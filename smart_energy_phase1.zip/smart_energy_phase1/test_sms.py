from sms import send_sms

send_sms("8825865625", "Test SMS from Smart Energy App")
