DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "Surya@2024",
    "database": "smart_energy"
}

BIMONTHLY_BUDGET = 1200  # ₹
TOTAL_DAYS = 60
AVG_UNIT_COST = 4.0
# -------- TWILIO CONFIG --------
TWILIO_ACCOUNT_SID = "ACb93e9c5374afda9c3562497c523dba86"
TWILIO_AUTH_TOKEN = "0920d869b1dc87aac3f4928e67e885ef"
TWILIO_PHONE_NUMBER = "+17608245219"

USER_PHONE_NUMBER = "+91 93453 49902"  # verified number

