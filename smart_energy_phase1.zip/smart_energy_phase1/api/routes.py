from fastapi import APIRouter
from models.schemas import EnergyData
from services.energy_service import process_energy, engine
from database.db import get_connection

router = APIRouter()

@router.post("/energy")
def receive_energy(data: EnergyData):
    return process_energy(data.power, data.energy)

@router.get("/stats")
def get_stats():
    return {
        "daily_usage": round(engine.daily_usage, 4),
        "excess_usage": round(engine.excess_usage, 4),
        "daily_limit": round(engine.daily_limit, 4),
        "usage_percent": round(
            (engine.daily_usage / engine.daily_limit) * 100, 2
        )
    }


@router.get("/alerts")
def get_alerts():
    db = get_connection()
    cursor = db.cursor(dictionary=True)
    cursor.execute("""
        SELECT timestamp, alert_type, message
        FROM alerts
        ORDER BY id DESC
        LIMIT 20
    """)
    data = cursor.fetchall()
    db.close()
    return data
