from datetime import datetime
from database.db import get_connection
from database.db import get_connection
from datetime import datetime

def log_alert(alert_type, message):
    db = get_connection()
    cursor = db.cursor()
    cursor.execute(
        "INSERT INTO alerts (timestamp, alert_type, message) VALUES (%s,%s,%s)",
        (datetime.now(), alert_type, message)
    )
    db.commit()
    db.close()

def check_alerts(percent):
    if percent >= 100:
        log_alert("CRITICAL", "Budget exceeded. Rebalancing applied.")
        return "CRITICAL"
    elif percent >= 90:
        log_alert("WARNING", "90% of daily budget used.")
        return "WARNING"
    elif percent >= 50:
        log_alert("INFO", "50% of daily budget used.")
        return "INFO"
    return None
