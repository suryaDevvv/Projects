import time
from datetime import datetime
from simulator import generate_power
from budget import BudgetEngine
from alerts import check_alerts
from database.db import get_connection

engine = BudgetEngine()

while True:
    power = generate_power()
    energy = power / 1000 / 3600  # kWh per second
    percent = engine.update_usage(energy)

    db = get_connection()
    cursor = db.cursor()
    cursor.execute(
        "INSERT INTO usage_data (timestamp, power, energy, daily_usage, usage_percent) VALUES (%s,%s,%s,%s,%s)",
        (datetime.now(), power, energy, engine.daily_usage, percent)
    )
    db.commit()
    db.close()

    alert = check_alerts(percent)
    if alert == "CRITICAL":
        engine.rebalance()

    print(f"{datetime.now()} | Power:{power:.2f}W | Used:{percent:.2f}%")

    time.sleep(1)
